# MEVCO International — complete website (v1)

Eight HTML files: **six corporate pages** (Home, About, What We Do, Product Categories, Partnerships, Contact), plus Privacy and Thank You. Responsive CSS, mobile menu JS, SVG logo, favicon and a **Netlify Forms-ready** manufacturer inquiry form.

## Preview locally

Open `index.html` in a browser, or run `python3 -m http.server 8000` inside this folder and visit http://localhost:8000. All navigation links work without a build system.

## Publish on Netlify

1. Sign up or log into https://app.netlify.com/ with a company-controlled account.
2. Choose **Add new project > Deploy manually** (wording may vary). Drag the unzipped `MEVCO_Website` directory to the deployment area. **No build command is needed.**
3. Netlify detects the HTML contact form (`data-netlify=true`) at deployment. Under **Forms**, confirm that `manufacturer-inquiry` appears, enable form processing if prompted, and configure **email notifications** to a real company-controlled address.
4. Send a test inquiry from the live site. Verify the submission is visible in Netlify Forms AND reaches the notification inbox; confirm spam filtering and rates. Do not advertise the form until this test passes.
5. In **Domain management**, add `mevcoint.com` only after you have registered/confirmed control of it. Follow Netlify's current DNS instructions with your domain registrar, then check HTTPS.
6. Update the corporate email/phone placeholder in `contact.html` and footer text in all files, have counsel approve `privacy.html`, and add any required legal details.

## If hosting somewhere other than Netlify

The pages will work, but the inquiry form **will not automatically deliver messages**. Integrate a server-side form service, Netlify Forms, or another approved forms endpoint. Never place private email or API credentials in frontend JavaScript.

## Changes & limitations

- Avoid claims of existing manufacturer partnerships, established national retail coverage or regulatory approvals until verified.
- Official legal identity and logo were based on the user's supplied branding discussions; confirm any final legal text before publication.
- Fonts load from Google Fonts and require connectivity; fall back to system fonts.
- `marveya.com` and other historical names are not used anywhere in this site.
- No analytics, tracking cookies, or third-party marketing scripts are included.
- To edit, update HTML text and `assets/site.css`, redeploy. An employee familiar with basic HTML can manage it.
- Have legal counsel review privacy disclosure, company details, and any sector-related advertising claims.
